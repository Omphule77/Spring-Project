package com.example.crudejpa.jpahibernatedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpahibernatedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
